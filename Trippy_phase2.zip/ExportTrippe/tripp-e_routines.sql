CREATE DATABASE  IF NOT EXISTS `tripp-e` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `tripp-e`;
-- MySQL dump 10.13  Distrib 8.0.21, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: tripp-e
-- ------------------------------------------------------
-- Server version	8.0.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `group_buget_trip`
--

DROP TABLE IF EXISTS `group_buget_trip`;
/*!50001 DROP VIEW IF EXISTS `group_buget_trip`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `group_buget_trip` AS SELECT 
 1 AS `TripId`,
 1 AS `Description`,
 1 AS `Value`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `winning_poll`
--

DROP TABLE IF EXISTS `winning_poll`;
/*!50001 DROP VIEW IF EXISTS `winning_poll`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `winning_poll` AS SELECT 
 1 AS `MAX(Votes)`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `trip_nickname`
--

DROP TABLE IF EXISTS `trip_nickname`;
/*!50001 DROP VIEW IF EXISTS `trip_nickname`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `trip_nickname` AS SELECT 
 1 AS `TripId`,
 1 AS `Username`,
 1 AS `Nickname`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `max_poll`
--

DROP TABLE IF EXISTS `max_poll`;
/*!50001 DROP VIEW IF EXISTS `max_poll`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `max_poll` AS SELECT 
 1 AS `MAX(Votes)`,
 1 AS `PollId`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `location_display`
--

DROP TABLE IF EXISTS `location_display`;
/*!50001 DROP VIEW IF EXISTS `location_display`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `location_display` AS SELECT 
 1 AS `ObjectId`,
 1 AS `TrippID`,
 1 AS `Location`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `travel_option_display`
--

DROP TABLE IF EXISTS `travel_option_display`;
/*!50001 DROP VIEW IF EXISTS `travel_option_display`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `travel_option_display` AS SELECT 
 1 AS `ObjectId`,
 1 AS `Location`,
 1 AS `ArrivalTime`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `full_cars`
--

DROP TABLE IF EXISTS `full_cars`;
/*!50001 DROP VIEW IF EXISTS `full_cars`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `full_cars` AS SELECT 
 1 AS `ObjectId`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `passenger_occupancy`
--

DROP TABLE IF EXISTS `passenger_occupancy`;
/*!50001 DROP VIEW IF EXISTS `passenger_occupancy`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `passenger_occupancy` AS SELECT 
 1 AS `Username`,
 1 AS `SeatNumber`,
 1 AS `ObjectId`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `people_on_each_trip`
--

DROP TABLE IF EXISTS `people_on_each_trip`;
/*!50001 DROP VIEW IF EXISTS `people_on_each_trip`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `people_on_each_trip` AS SELECT 
 1 AS `TripId`,
 1 AS `TripName`,
 1 AS `COUNT(tripmembers.username)`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `reminders_trip`
--

DROP TABLE IF EXISTS `reminders_trip`;
/*!50001 DROP VIEW IF EXISTS `reminders_trip`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `reminders_trip` AS SELECT 
 1 AS `Name`,
 1 AS `Tripid`,
 1 AS `Time`,
 1 AS `Description`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `traveloptiondisplay`
--

DROP TABLE IF EXISTS `traveloptiondisplay`;
/*!50001 DROP VIEW IF EXISTS `traveloptiondisplay`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `traveloptiondisplay` AS SELECT 
 1 AS `ObjectId`,
 1 AS `Location`,
 1 AS `ArrivalTime`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `avg_individal_budget`
--

DROP TABLE IF EXISTS `avg_individal_budget`;
/*!50001 DROP VIEW IF EXISTS `avg_individal_budget`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `avg_individal_budget` AS SELECT 
 1 AS `AVG(group_entry.Value)`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `group_buget_trip`
--

/*!50001 DROP VIEW IF EXISTS `group_buget_trip`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `group_buget_trip` AS select `group_entry`.`TripId` AS `TripId`,`group_entry`.`Description` AS `Description`,`group_entry`.`Value` AS `Value` from ((`group_entry` left join `group_budget` on((`group_entry`.`TripId` = `group_budget`.`TripId`))) left join `trip` on((`trip`.`TripId` = `group_budget`.`TripId`))) order by `group_entry`.`TripId` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `winning_poll`
--

/*!50001 DROP VIEW IF EXISTS `winning_poll`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `winning_poll` AS select max(`poll_entry`.`Votes`) AS `MAX(Votes)` from `poll_entry` group by `poll_entry`.`PollId` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `trip_nickname`
--

/*!50001 DROP VIEW IF EXISTS `trip_nickname`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `trip_nickname` AS select `trip`.`TripId` AS `TripId`,`user`.`Username` AS `Username`,`user`.`Nickname` AS `Nickname` from ((`user` left join `members` on((`user`.`Username` = `members`.`Username`))) left join `trip` on((`members`.`TripId` = `trip`.`TripId`))) order by `trip`.`TripId` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `max_poll`
--

/*!50001 DROP VIEW IF EXISTS `max_poll`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `max_poll` AS select max(`poll_entry`.`Votes`) AS `MAX(Votes)`,`poll_entry`.`PollId` AS `PollId` from `poll_entry` group by `poll_entry`.`PollId` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `location_display`
--

/*!50001 DROP VIEW IF EXISTS `location_display`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `location_display` AS select `traval_option`.`ObjectId` AS `ObjectId`,`traval_option`.`TrippID` AS `TrippID`,`travel_object`.`Location` AS `Location` from (`traval_option` left join (select `cars`.`ObjectId` AS `ObjectId`,`cars`.`Location` AS `Location` from `cars` union select `custom_travel`.`ObjectId` AS `ObjectId`,`custom_travel`.`Location` AS `Location` from `custom_travel`) `travel_object` on((`traval_option`.`ObjectId` = `travel_object`.`ObjectId`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `travel_option_display`
--

/*!50001 DROP VIEW IF EXISTS `travel_option_display`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `travel_option_display` AS select `traval_option`.`ObjectId` AS `ObjectId`,`destination`.`Location` AS `Location`,`destination`.`ArrivalTime` AS `ArrivalTime` from ((`traval_option` left join `cars` on((`traval_option`.`ObjectId` = `cars`.`ObjectId`))) left join `destination` on((`cars`.`ObjectId` = `destination`.`ObjectId`))) where (`destination`.`Priority` = 1) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `full_cars`
--

/*!50001 DROP VIEW IF EXISTS `full_cars`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `full_cars` AS select `cars`.`ObjectId` AS `ObjectId` from `cars` where `cars`.`Seats` = all (select count(`passenger`.`SeatNumber`) from `passenger` group by `passenger`.`ObjectId`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `passenger_occupancy`
--

/*!50001 DROP VIEW IF EXISTS `passenger_occupancy`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `passenger_occupancy` AS select `passenger`.`Username` AS `Username`,`passenger`.`SeatNumber` AS `SeatNumber`,`cars`.`ObjectId` AS `ObjectId` from (`passenger` left join `cars` on((`passenger`.`ObjectId` = `cars`.`ObjectId`))) union select `passenger`.`Username` AS `Username`,`passenger`.`SeatNumber` AS `SeatNumber`,`cars`.`ObjectId` AS `ObjectId` from (`cars` left join `passenger` on((`passenger`.`ObjectId` = `cars`.`ObjectId`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `people_on_each_trip`
--

/*!50001 DROP VIEW IF EXISTS `people_on_each_trip`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `people_on_each_trip` AS select `tripmembers`.`TripId` AS `TripId`,`tripmembers`.`TripName` AS `TripName`,count(`tripmembers`.`username`) AS `COUNT(tripmembers.username)` from (select `members`.`Username` AS `username`,`trip`.`TripId` AS `TripId`,`trip`.`TripName` AS `TripName` from (`members` left join `trip` on((`members`.`TripId` = `trip`.`TripId`))) order by `trip`.`TripId`) `tripmembers` group by `tripmembers`.`TripId` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `reminders_trip`
--

/*!50001 DROP VIEW IF EXISTS `reminders_trip`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `reminders_trip` AS select `reminders`.`Name` AS `Name`,`reminders`.`Tripid` AS `Tripid`,`reminders`.`Time` AS `Time`,`reminders`.`Description` AS `Description` from `reminders` order by `reminders`.`Tripid` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `traveloptiondisplay`
--

/*!50001 DROP VIEW IF EXISTS `traveloptiondisplay`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `traveloptiondisplay` AS select `traval_option`.`ObjectId` AS `ObjectId`,`destination`.`Location` AS `Location`,`destination`.`ArrivalTime` AS `ArrivalTime` from ((`traval_option` left join `cars` on((`traval_option`.`ObjectId` = `cars`.`ObjectId`))) left join `destination` on((`cars`.`ObjectId` = `destination`.`ObjectId`))) where (`destination`.`Priority` = 1) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `avg_individal_budget`
--

/*!50001 DROP VIEW IF EXISTS `avg_individal_budget`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `avg_individal_budget` AS select avg(`group_entry`.`Value`) AS `AVG(group_entry.Value)` from `group_entry` group by `group_entry`.`TripId` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-11-07 22:13:56
